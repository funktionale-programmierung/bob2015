//: Immutability - noun: not subject or susceptible to change

//: ## Referenztypen
class Dog {
    var legs = 4
}

var bello = Dog()
var bello2 = bello

bello.legs = 5 // ändert auch bello2!
bello
bello2

//: ### let für Referenztypen
let hasso = Dog()
hasso.legs = 6
// hasso = Dog() // cannot assign to value: 'hasso' is a 'let' constant

//: ## Value Types
struct Cat {
    var ears = 2
}

var kitty = Cat()
var kitty2 = kitty // Zuweisung kopiert den Wert von kitty

kitty.ears = 3 // kitty2 bleibt unverändert
kitty
kitty2

//: ### let für Value Types
let lulu = Cat()
//lulu.ears = 4 // cannot assign to property: 'lulu' is a 'let' constant

//: #### Funktionsargument sind per Default mit let definiert

func goCrazy(someCat: Cat) {
    //someCat.ears = 20
}

goCrazy(kitty)
goCrazy(lulu)

