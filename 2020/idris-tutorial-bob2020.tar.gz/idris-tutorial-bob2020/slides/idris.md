% Idris Tutorial
% Stefan Wehr (wehr@cp-med.com)
% 28.2.2020

# What are static types?

- Prevent data misinterpretation

```java
int addOne(int i) { return i+1; }

addOne(3);
addOne("3");  // Error, "3" is a string
```

- Allow for modularity and abstraction
- Lightweight formal method

# What are dependent types?

- Idea: use terms/expressions in types
- Usually, there is a strict distinction between the term- and the type-level.
- A language with dependent types does not have this strict distinction between terms and types.

```haskell
boolOrChar : Bool -> Type
boolOrChar False = Char
boolOrChar True  = Bool

toString : (isChar : Bool) -> boolOrChar isChar -> String
toString False c    = singleton c  -- c is a Char 
toString True False = "F"          -- c is a Bool
toString True True  = "T"          -- c a Bool
```

* Type-checking requires evaluation:
  - If the type checker cannot prove totality of a term on the type-level, it does not evaluate it further.
  - Terms used in types cannot have side effects.

# What is Idris?

- A practially oriented programming language with dependent types
  - But not really ready for production
- Developed by Edwin Brady, Univ. St. Andrews, Scotland  
- Greatly influenced by Haskell
  - Design principle: "What if Haskell had full dependent types?"
  - But strict by default
  - With dependent types

# A first example in Idris: printf

- Data Types
```haskell
data Format =
      FString Format     -- %s
    | FLit String Format -- a literal string
    | FEnd
```

- Definitions
```haskell
-- "name = %s"
exampleFormat : Format
exampleFormat = FLit "name = " (FString FEnd)
```

- Functions
```haskell
toFormat : String -> Format
toFormat s = loop (unpack s)
  where
    prepend : Char -> Format -> Format
    prepend c (FLit s fmt) = FLit (strCons c s) fmt
    prepend c fmt          = FLit (singleton c) fmt
    loop : List Char -> Format
    loop []                   = FEnd
    loop ('%' :: 's' :: rest) = FString (loop rest)
    loop ('%' :: '%' :: rest) = prepend '%' (loop rest)
    loop (c :: rest)          = prepend c (loop rest)
```

- Functions on types
```haskell
PrintfType : Format -> Type
PrintfType (FString f) = String -> PrintfType f
PrintfType (FLit s f) = PrintfType f
PrintfType FEnd = String
```

- Values on the type-level
```haskell
printf' : (f : Format) -> String -> PrintfType f
printf' (FString x) acc = \s => printf' x (acc ++ s)
printf' (FLit x y) acc = printf' y (acc ++ x)
printf' FEnd acc = acc

printf : (s : String) -> PrintfType (toFormat s)
printf s = printf' (toFormat s) ""
```

# Type-driven development

- Incrementally refine your program, guided by type information

|                      | Vim  | Emacs   | Atom       |
|----------------------|------|---------|------------|
| Open response window | \\i  |         |            |
| Reload file          | \\r  | C-c C-l | Cntl-Alt-R |
| Show type            | \\t  | C-c C-t | Cntl-Alt-T |
| Create definition    | \\d  | C-c C-s | Cntl-Alt-A |
| Case split           | \\c  | C-c C-c | Cntl-Alt-C |
| Proof search         | \\p  |         | Cntl-Alt-S |

- Guide name generation when doing case split

```haskell
%name Format f, f1, f2, f3
```

# Exercise

- Extend the `Format` data type with an alternative for `%d` specifier for printing ints.
- Extend the example format so that it represents `"name = %s, age = %d"`
- Extend the rest of the code so that `printf "name = %s, age = %d" "Stefan" 41` yields `"name = Stefan, age = 41"`

# Another example: length-indexed vectors

- Natural numbers

```haskell
data Nat = Z | S Nat
```

- Vectors carrying their own length: a value of type `Vect n String` is a
vector of Strings with length `n`.

```haskell
infixr 7 ::

data Vect : Nat -> Type -> Type where
  Nil : Vect Z a
  (::) : a -> Vect n a -> Vect (S n) a

%name Vect xs,ys,zs,ws
```

- The `head` function can now be defined as a total function.

```haskell
total head : Vect (S n) a -> a
head (x :: _) = x
```

# Exercises

- Write a function for appending two vectors

```haskell
total append : Vect n a -> Vect m a -> Vect (n + m) a
```

- Write the `zip` function
```haskell
total zip : Vect n a -> Vect n b -> Vect n (a, b)
```

- Advanced: implement indexed access

```haskell
total elemAt : (k : Nat) -> Vect n a -> LT k n -> a
```

The predicates `LT` for `<` and `LTE` for `<=` are defined as follows:

```haskell
-- Proofs that `n` is less than or equal to `m`
data LTE  : (n, m : Nat) -> Type where
  LTEZero : LTE Z n
  LTESucc : LTE left right -> LTE (S left) (S right)

-- Strict less than
total LT : Nat -> Nat -> Type
LT left right = LTE (S left) right
```

# Idris and the real world

- The functions seen so far cannot have side-effects.
- The type system distinguishes between
  - pure functions
  - effectful computations
- An effectful computation producing a value of type `a` has type `IO a`.
- Sequencing of effectful computations is done via the `do` notation (as in Haskell).
- For now, we only need the following two effectful computations:
```haskell
putStrLn :: String -> IO ()
getLine :: IO String
```

# Example: `sayHello`

```haskell
sayHello : IO ()
sayHello =
  do putStrLn "What's your name?"
     name <- getLine
     putStrLn ("Hello " ++ name)
```

- We need to use `:exec sayHello` in the Idris interpreter to run the effectful computation `sayHello`.
- `name <- getLine` executes the computation `getLine` and binds the result to `name`.

# Reading vectors from stdin

- Goal: write a function `readVect` that reads from stdin until an empty line is encountered. The function then returns a vector of all strings read (without the empty line).
- Problem: a vector needs to carry its length but we don't know in advance how many lines will be available.
- Solution: use dependent pairs!

# Dependent pair types

- A dependent pair type is simular to a ordinary pair type but the value of the first component can be used in the type of the second component.
- Example: `(n : Nat ** Vect n String)`
  - First component is a natural number.
  - Second component is a vector of strings.
  - Length of the vector in the second component is given by the first component.

# Exercise: implement `readVect`

```haskell
readVect : IO (n : Nat ** Vect n String)
```

- Hint: if-then-else works as in Haskell
```haskell
if condition
   then ...
   else ...
```
- Hint: use `pure : a -> IO a` to inject a value into an effectful computation
- Hint: you can pattern match on dependent pairs: `(n ** elems) <- readVect` runs the computation readVect and names the first component of the result as `n`, the
second as `elems`.

# Exercise: read two vectors from stdin and `zip` them

Implement the function `readAndZipVectors : IO ()`. The function should behave as follows: 

- First, it displays the message `"First vector"` to the user and reads the first vector.
- Next, it displays the message `"Second vector"` to the user and reads the second vector.
- Finally, it checks whether to two vectors have the same length. If not, an error
message is displayed. Otherwise, the result of zipping both vectors is displayed.
- Hint: use the function `exactLength : (len : Nat) -> Vect m a -> Maybe (Vect len a)` for checking whether a vector has the expected length.
- Hint: use the function `show` for converting a vector into a string.

# Code generation

- So far, we only used the Idris interpreter.
- Idris 1.3.1 supports the following targets for producing executables: C, Javascript, Node, Bytecode
- Performance seems to be good
  - I did not measure with real-world applications

# Resources

- Type-Driven Development with Idris. Edwin Brady. Manning, 2017.
- Idris, a General Purpose Dependently Typed Programming Language: Design and Implementation. Edwin Brady. Journal of Functional Programming, 2013.
- Idris 2: Type-Driven Development of Idris. Edwin Brady. Talk at Code Mesh 2018, https://www.youtube.com/watch?v=mOtKD7ml0NU
- Language reference: http://docs.idris-lang.org/en/latest/reference/index.html

# Things to take home

- Dependent types blur the distinction between the value and the type level.
- Values used in types allow to express more invariants to be checked while compiling the program.
- Idris is a programing language with dependent types with a focus on real world applications.
  - ... but it's still a research language

